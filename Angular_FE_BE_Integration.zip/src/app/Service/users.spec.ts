import { TestBed } from '@angular/core/testing';

import { Users } from './users';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('Users', () => {
  let service: Users;
  let httpMock:HttpTestingController

  beforeEach(() => {
    TestBed.configureTestingModule({
    // service = TestBed.inject(Users),
    imports:  [HttpClientTestingModule], 
    providers:[Users]
    });
    service = TestBed.inject(Users);
    httpMock = TestBed.inject(HttpTestingController);

  });

  afterEach(()=> {
    httpMock.verify();
  });
  it("should be created ", () => {
    expect(service).toBeTruthy();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
