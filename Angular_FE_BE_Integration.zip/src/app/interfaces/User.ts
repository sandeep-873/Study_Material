export interface User{
    name:"",
    age:number,
    email:string,
    id:string
}