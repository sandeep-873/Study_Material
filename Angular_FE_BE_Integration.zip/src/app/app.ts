import { Component, signal } from '@angular/core';
import { Users } from './Service/users';
import { User } from './interfaces/User';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  imports: [FormsModule],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  users: User[] = []
  selectedUser: User | undefined;
  constructor(private userService: Users) {

  }
  ngOnInit() {
    this.showUsers()
  }
  showUsers() {
    this.userService.getUsers().subscribe((data: User[]) => { this.users = data })

  }
  addUser(user: User) {
    if (!this.selectedUser) {
      this.userService.saveUser(user).subscribe((data: User) => {
        if (data) {
          this.showUsers()
        }
      })
    }
    else {
      const userData = { ...user, id: this.selectedUser.id }
      this.userService.updateUser(userData).subscribe((data) => {
        console.log(data);
        if (data) {
          this.showUsers()
        }
      })
    }
  }

  deleteUser(id: string) {
    console.log(id);
    this.userService.deleteUser(id).subscribe((data: User) => {
      if (data) {
        this.showUsers()
      }
    })
  }

  selectUser(id: string) {
    this.userService.selectUser(id).subscribe((data) => {
      this.selectedUser = data
      console.log(data);
    })
  }

}
