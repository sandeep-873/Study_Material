import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-profile',
  imports: [],
  templateUrl: './profile.html',
  styleUrl: './profile.css'
})
export class Profile {
  userName: string | null = ""
  lastName: string | null = ""
  constructor(private route: ActivatedRoute) {
  }

  //Method 1
  ngOnInit() {
      this.userName = this.route.snapshot.paramMap.get('name')
      this.lastName = this.route.snapshot.paramMap.get('lastname')
      console.log(this.lastName);
      
      console.log(this.userName)

  
    // //Method 2
    // this.route.queryParams.subscribe(params => {
    //   this.userName = params['name']
    //   this.lastName = params['lastName']
    // })

    //Method 3
    // this.route.data.subscribe(params =>{
    //   this.userName = params['name']
    // })
  }
}

