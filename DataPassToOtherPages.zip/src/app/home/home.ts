import { Component } from '@angular/core';
import { Profile } from '../profile/profile';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  imports: [Profile,RouterLink],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class Home {

  constructor(private router:Router){}
  goToProfile(name:string){
    this.router.navigate(['profile'],{queryParams:{name:name,lastName:'Smith'}})
  }
}
