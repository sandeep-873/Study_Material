import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-user',
  imports: [],
  templateUrl: './user.html',
  styleUrl: './user.css'
})
export class User {
  @Output() getUsers = new EventEmitter();
  @Output() testData = new EventEmitter();

  users = ['sam', 'jack', 'ram', 'tom']
  ngOnInit() {
    this.getUsers.emit(this.users);
  }
}
